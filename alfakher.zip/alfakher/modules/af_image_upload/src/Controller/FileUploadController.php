<?php
namespace Drupal\af_image_upload\Controller;

use Drupal\Core\Session\AccountInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Access\AccessResult;

/**
 * Process file uploads.
 */
class FileUploadController {

  /**
   * Allow access for logged-in, authenitcated users.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   Run access checks for this account.
   */
  public function access(AccountInterface $account) {
    return AccessResult::allowedIf($account->isAuthenticated());
  }

  /**
   * Process posted files.
   */
  public function create(Request $request) {
    /*if (strpos($request->headers->get('Content-Type'), 'multipart/form-data;') !== 0) {
      $res = new JsonResponse();
      $res->setStatusCode(400, 'must submit multipart/form-data');
      return $res;
    }*/
	$date = date('Y-m');
	$path = 'public://' .$date. '/';
    $data = file_get_contents($_FILES['image']['tmp_name']);
    $mime = $_FILES['image']['type'];
	$destination = "public://".$date."/".$_FILES['image']['name'];
	if (file_prepare_directory($path, FILE_CREATE_DIRECTORY)) {
		$file = file_save_data($data, $destination , FILE_EXISTS_REPLACE);
		$response['file_id'] = $file->id();		
	} else {
		$response['error'] = 'Folder Error';		
	}
    return new JsonResponse($response);
  }
}