<?php

namespace Drupal\af_agevalidate\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Config\ConfigFactory;

/**
 * Provides a 'AfAgevalidateBlock' block.
 *
 * @Block(
 *   id = "af_agevalidate",
 *   admin_label = @Translation("AF Agevalidate"),
 *   category = @Translation("AF Custom")
 * )
 */
class AfAgevalidateBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Config factory object.
   *
   * @var \Drupal\Core\Config\Config|\Drupal\Core\Config\ImmutableConfig
   */

  protected $config;

  /**
   * AfAgevalidateBlock constructor.
   *
   * @param array $configuration
   *   Configuration.
   * @param string $plugin_id
   *   PLugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \Drupal\Core\Config\ConfigFactory $config
   *   Config factory.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, ConfigFactory $config) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->config = $config;
  }

  /**
   * Dependency injection.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   Container interface.
   * @param array $configuration
   *   Configuration.
   * @param string $plugin_id
   *   Plugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   *
   * @return static
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {

    $config = $this->config->get('af_misc.settings');
    $build['terms_nid'] = $config->get('terms_nid');
    $build['privacy_nid'] = $config->get('privacy_nid');
    return $build;
  }

}
