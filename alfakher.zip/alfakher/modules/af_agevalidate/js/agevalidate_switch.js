/**
 * @file
 * Agevalidate.
 */

(function($, Drupal) {
  Drupal.behaviors.agagateBehaviorLite = {
    attach: function(context, settings) {
      $("body", context)
        .once("agegateSwitch")
        .each(function() {
          Drupal.behaviors.agagateBehaviorLite.ageGateHeight();
          $(window).resize(function() {
            Drupal.behaviors.agagateBehaviorLite.ageGateHeight();
          });
          // Check cookie on site load.
          if ($.cookie("is_legal") === "yes") {
            $(".agegate-wrapper").remove();
            $("body").addClass("overlay-hidden");
            $("body").removeClass("agegate-active");
          } else {
            $("body").addClass("agegate-active");
            $(window).scrollTop(0);
          }

          // Set Cookie with correct condition and pass agegate.
          $("#agegate-yes").click(function() {
            $.cookie("is_legal", "yes", {
              expires: 2030,
              domain: window.location.hostname,
              path: "/"
            });
            $(".agegate-wrapper").fadeOut();
            $("body").addClass("overlay-hidden");
            $("body").removeClass("agegate-active");
          });

          // Set Cookie with wrong condition and show agegate sorry step.
          $("#agegate-no").click(function() {
            $(".agegate-sorry-step").removeClass("d-none");
            $(".agegate-form-step").addClass("d-none");
          });
        });

        // Terms conditions and privacy policy pages redirect condition.
        if(typeof(settings.escape_urls) !== 'undefined') {
          if (window.location.href.indexOf(settings.escape_urls.terms_url) > 0 || window.location.href.indexOf(settings.escape_urls.privacy_url) > 0) {
            $(".agegate-wrapper").remove();
            $("body").removeClass("agegate-active").addClass('overlay-hidden');
          }
        }
    },
    ageGateHeight: function ageGateHeight() {
      if (navigator.userAgent.match(/iP(hone|od|ad)/i)) {
        $("body").addClass("ios");
        const menuHeight = $(window).innerHeight();
        $(".agegate-wrapper").css({
          height: menuHeight + "px"
        });
      }
    }
  };
})(jQuery, Drupal);
